<%@ page import="java.sql.*" %>
<%@ page session="true" %>
<%
    // Authentication check
    if (!"admin".equals(session.getAttribute("role"))) {
        response.sendRedirect("login.jsp");
        return;
    }

    String message = "";
    String searchCategory = request.getParameter("searchCategory");
    String searchStudent = request.getParameter("searchStudent");
    String minRating = request.getParameter("minRating");

    // Handle feedback deletion
    if ("POST".equalsIgnoreCase(request.getMethod()) && request.getParameter("deleteId") != null) {
        String deleteId = request.getParameter("deleteId");
        
        try {
            Class.forName("org.sqlite.JDBC");
            String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
            Connection deleteConn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
            
            PreparedStatement deleteStmt = deleteConn.prepareStatement(
                "DELETE FROM feedback WHERE id = ?");
            deleteStmt.setInt(1, Integer.parseInt(deleteId));
            
            int deleted = deleteStmt.executeUpdate();
            message = (deleted > 0) ? 
                "<i class='fas fa-check-circle'></i> Feedback deleted successfully!" : 
                "<i class='fas fa-exclamation-circle'></i> Feedback not found.";
            
            deleteStmt.close();
            deleteConn.close();
        } catch (Exception e) {
            message = "<i class='fas fa-times-circle'></i> Error deleting feedback: " + e.getMessage();
        }
    }

    // Database connection for listing feedback
    Class.forName("org.sqlite.JDBC");
    String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
    Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    
    // Build query based on search
    String query = "SELECT * FROM feedback";
    boolean hasWhere = false;
    
    if (searchCategory != null && !searchCategory.trim().isEmpty()) {
        query += " WHERE category LIKE ?";
        hasWhere = true;
    }
    
    if (searchStudent != null && !searchStudent.trim().isEmpty()) {
        query += hasWhere ? " AND" : " WHERE";
        query += " student LIKE ?";
        hasWhere = true;
    }
    
    if (minRating != null && !minRating.trim().isEmpty()) {
        query += hasWhere ? " AND" : " WHERE";
        query += " rating >= ?";
    }
    
    query += " ORDER BY created_at DESC";
    
    PreparedStatement stmt = conn.prepareStatement(query);
    int paramIndex = 1;
    
    if (searchCategory != null && !searchCategory.trim().isEmpty()) {
        stmt.setString(paramIndex++, "%" + searchCategory + "%");
    }
    
    if (searchStudent != null && !searchStudent.trim().isEmpty()) {
        stmt.setString(paramIndex++, "%" + searchStudent + "%");
    }
    
    if (minRating != null && !minRating.trim().isEmpty()) {
        stmt.setInt(paramIndex++, Integer.parseInt(minRating));
    }
    
    ResultSet rs = stmt.executeQuery();
%>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Feedback - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: var(--dark-color);
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .message {
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            font-size: 14px;
            display: flex;
            align-items: center;
            animation: slideDown 0.4s ease-out;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .message-success {
            background-color: #e6ffed;
            color: var(--success-color);
            border: 1px solid #b7eb8f;
        }
        
        .message-error {
            background-color: #ffebee;
            color: var(--error-color);
            border: 1px solid #ffcdd2;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }
        
        .search-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        
        .search-card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: var(--primary-color);
            display: flex;
            align-items: center;
        }
        
        .search-card h2 i {
            margin-right: 10px;
        }
        
        .search-form {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 14px;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .search-actions {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        
        .feedback-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .feedback-table th {
            background: var(--primary-color);
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 500;
        }
        
        .feedback-table td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .feedback-table tr:last-child td {
            border-bottom: none;
        }
        
        .feedback-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .feedback-table tr:hover {
            background-color: #f1f1f1;
        }
        
        .rating-stars {
            color: #ffc107;
            font-size: 16px;
        }
        
        .rating-value {
            font-weight: 500;
            margin-left: 5px;
        }
        
        .comments-cell {
            max-width: 300px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .comments-cell:hover {
            white-space: normal;
            overflow: visible;
            position: relative;
            z-index: 1;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
        }
        
        .action-btn i {
            margin-right: 5px;
        }
        
        .delete-btn {
            background: #dc3545;
            color: white;
        }
        
        .delete-btn:hover {
            background: #c82333;
        }
        
        .no-feedback {
            text-align: center;
            padding: 30px;
            color: #666;
            font-style: italic;
        }
        
        .back-link {
            margin-top: 30px;
        }
        
        .back-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            transition: all 0.2s ease;
        }
        
        .back-link a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .back-link a i {
            margin-right: 8px;
        }
        
        .search-results-info {
            margin-bottom: 15px;
            color: #666;
            font-size: 14px;
        }
        
        @media (max-width: 768px) {
            .feedback-table {
                display: block;
                overflow-x: auto;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 5px;
            }
            
            .search-form {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Feedback Management</h1>
            <a href="adminDashboard.jsp" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <% if (!message.isEmpty()) { %>
            <div class="message <%= message.contains("successfully") ? "message-success" : "message-error" %>">
                <%= message %>
            </div>
        <% } %>
        
        <!-- Search Card -->
        <div class="search-card">
            <h2><i class="fas fa-search"></i> Search Feedback</h2>
            
            <form method="get" class="search-form">
                <div class="form-group">
                    <label for="searchCategory">Category</label>
                    <input type="text" id="searchCategory" name="searchCategory" 
                           placeholder="e.g., Mental Health" value="<%= searchCategory != null ? searchCategory : "" %>">
                </div>
                
                <div class="form-group">
                    <label for="searchStudent">Student Name</label>
                    <input type="text" id="searchStudent" name="searchStudent" 
                           placeholder="e.g., John Doe" value="<%= searchStudent != null ? searchStudent : "" %>">
                </div>
                
                <div class="form-group">
                    <label for="minRating">Minimum Rating</label>
                    <select id="minRating" name="minRating">
                        <option value="">Any Rating</option>
                        <option value="5" <%= "5".equals(minRating) ? "selected" : "" %>>5 Stars</option>
                        <option value="4" <%= "4".equals(minRating) ? "selected" : "" %>>4+ Stars</option>
                        <option value="3" <%= "3".equals(minRating) ? "selected" : "" %>>3+ Stars</option>
                        <option value="2" <%= "2".equals(minRating) ? "selected" : "" %>>2+ Stars</option>
                        <option value="1" <%= "1".equals(minRating) ? "selected" : "" %>>1+ Stars</option>
                    </select>
                </div>
                
                <div class="search-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Search
                    </button>
                    <a href="manageFeedback.jsp" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Clear
                    </a>
                </div>
            </form>
            
            <% if ((searchCategory != null && !searchCategory.trim().isEmpty()) || 
                  (searchStudent != null && !searchStudent.trim().isEmpty()) ||
                  (minRating != null && !minRating.trim().isEmpty())) { %>
                <div class="search-results-info">
                    Showing results for: 
                    <% if (searchCategory != null && !searchCategory.trim().isEmpty()) { %>
                        <strong>Category: <%= searchCategory %></strong>
                    <% } %>
                    <% if (searchStudent != null && !searchStudent.trim().isEmpty()) { %>
                        <% if (searchCategory != null && !searchCategory.trim().isEmpty()) { %> | <% } %>
                        <strong>Student: <%= searchStudent %></strong>
                    <% } %>
                    <% if (minRating != null && !minRating.trim().isEmpty()) { %>
                        <% if (searchCategory != null || searchStudent != null) { %> | <% } %>
                        <strong>Rating: <%= minRating %>+ stars</strong>
                    <% } %>
                </div>
            <% } %>
        </div>
        
        <!-- Feedback Table -->
        <table class="feedback-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Student</th>
                    <th>Category</th>
                    <th>Comments</th>
                    <th>Rating</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <% 
                boolean hasData = false;
                while (rs.next()) { 
                    hasData = true;
                    int rating = rs.getInt("rating");
                %>
                    <tr>
                        <td><%= rs.getInt("id") %></td>
                        <td><%= rs.getString("student") %></td>
                        <td><%= rs.getString("category") %></td>
                        <td class="comments-cell" title="<%= rs.getString("comments") %>">
                            <%= rs.getString("comments") %>
                        </td>
                        <td>
                            <span class="rating-stars">
                                <% for (int i = 1; i <= 5; i++) { %>
                                    <i class="fas <%= i <= rating ? "fa-star" : "fa-star-half-alt" %>"></i>
                                <% } %>
                            </span>
                            <span class="rating-value"><%= rating %></span>
                        </td>
                        <td><%= rs.getString("created_at") %></td>
                        <td>
                            <div class="action-buttons">
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="deleteId" value="<%= rs.getInt("id") %>">
                                    <button type="submit" class="action-btn delete-btn" 
                                            onclick="return confirm('Are you sure you want to delete this feedback?')">
                                        <i class="fas fa-trash-alt"></i> Delete
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <% } %>
                
                <% if (!hasData) { %>
                    <tr>
                        <td colspan="7" class="no-feedback">
                            <i class="fas fa-info-circle"></i> No feedback found
                            <% if (searchCategory != null || searchStudent != null || minRating != null) { %>
                                matching your search criteria.
                            <% } else { %>
                                in the system.
                            <% } %>
                        </td>
                    </tr>
                <% } %>
            </tbody>
        </table>
        
        <div class="back-link">
            <a href="adminDashboard.jsp"><i class="fas fa-arrow-left"></i> Back to Admin Dashboard</a>
        </div>
    </div>
</body>
</html>
<%
    // Close database resources
    if (rs != null) rs.close();
    if (stmt != null) stmt.close();
    if (conn != null) conn.close();
%>