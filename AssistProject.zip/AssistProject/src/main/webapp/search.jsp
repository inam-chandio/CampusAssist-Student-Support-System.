<%@ page import="java.sql.*" %>
<%@ page session="true" %>
<%
    // Authentication check
    String role = (String) session.getAttribute("role");
    if (role == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    String keyword = request.getParameter("keyword");
    boolean isAdmin = "admin".equals(role);
    
    // CORRECTED: Use consistent database path
    Class.forName("org.sqlite.JDBC");
    String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
    Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
%>
<!DOCTYPE html>
<html>
<head>
    <title>Search - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        
        .search-container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 0.6s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .search-header {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            background: var(--primary-color);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .search-header h1 {
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .search-header p {
            opacity: 0.9;
            font-size: 16px;
        }
        
        .search-form {
            padding: 30px;
            display: flex;
            gap: 10px;
        }
        
        .search-input {
            flex: 1;
            padding: 15px 20px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        .search-input:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(72, 149, 239, 0.2);
            outline: none;
        }
        
        .search-btn {
            padding: 15px 30px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            font-size: 16px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
        }
        
        .search-btn:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .search-btn i {
            margin-right: 8px;
        }
        
        .results-section {
            padding: 0 30px 30px;
        }
        
        .section-title {
            font-size: 22px;
            font-weight: 500;
            margin: 30px 0 20px;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            padding-bottom: 10px;
            border-bottom: 2px solid #eee;
        }
        
        .section-title i {
            margin-right: 10px;
            color: var(--primary-color);
        }
        
        .no-results {
            text-align: center;
            padding: 30px;
            color: #666;
            font-style: italic;
        }
        
        .faq-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        .faq-question {
            font-weight: 500;
            font-size: 18px;
            margin-bottom: 10px;
            color: var(--dark-color);
        }
        
        .faq-answer {
            color: #555;
            line-height: 1.6;
        }
        
        .feedback-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
            border-left: 4px solid var(--accent-color);
        }
        
        .feedback-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .feedback-student {
            font-weight: 500;
            color: var(--dark-color);
        }
        
        .feedback-category {
            background: #e3f2fd;
            color: #1976d2;
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .feedback-comment {
            color: #555;
            line-height: 1.6;
            margin-bottom: 10px;
        }
        
        .feedback-rating {
            color: #ffc107;
            font-size: 16px;
        }
        
        .back-link {
            text-align: center;
            margin-top: 30px;
        }
        
        .back-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            transition: all 0.2s ease;
        }
        
        .back-link a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .back-link a i {
            margin-right: 8px;
        }
        
        @media (max-width: 768px) {
            .search-form {
                flex-direction: column;
            }
            
            .search-header {
                padding: 20px;
            }
            
            .results-section {
                padding: 0 20px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="search-container">
        <div class="search-header">
            <h1>Search Campus Resources</h1>
            <p>Find answers in our FAQs and feedback database</p>
        </div>
        
        <form method="get" class="search-form">
            <input type="text" name="keyword" class="search-input" 
                   placeholder="Enter your search terms..." value="<%= keyword != null ? keyword : "" %>">
            <button type="submit" class="search-btn">
                <i class="fas fa-search"></i> Search
            </button>
        </form>
        
        <div class="results-section">
            <% if (keyword != null && !keyword.trim().isEmpty()) { %>
                <!-- FAQ Results -->
                <h2 class="section-title">
                    <i class="fas fa-question-circle"></i>
                    Matching FAQs
                </h2>
                
                <%
                    PreparedStatement ps = conn.prepareStatement(
                        "SELECT * FROM faqs WHERE question LIKE ? OR answer LIKE ?");
                    ps.setString(1, "%" + keyword + "%");
                    ps.setString(2, "%" + keyword + "%");
                    ResultSet rs1 = ps.executeQuery();
                    
                    boolean hasFaqs = false;
                    while (rs1.next()) {
                        hasFaqs = true;
                %>
                        <div class="faq-card">
                            <div class="faq-question">
                                <i class="fas fa-question" style="color: var(--primary-color);"></i> 
                                <%= rs1.getString("question") %>
                            </div>
                            <div class="faq-answer">
                                <i class="fas fa-lightbulb" style="color: var(--accent-color);"></i> 
                                <%= rs1.getString("answer") %>
                            </div>
                        </div>
                <%
                    }
                    
                    if (!hasFaqs) {
                %>
                        <div class="no-results">
                            <i class="fas fa-info-circle"></i> No matching FAQs found
                        </div>
                <%
                    }
                    rs1.close();
                    ps.close();
                %>
                
                <!-- Feedback Results (only for admin) -->
                <% if (isAdmin) { %>
                    <h2 class="section-title">
                        <i class="fas fa-comment-alt"></i>
                        Matching Feedback
                    </h2>
                    
                    <%
                        ps = conn.prepareStatement(
                            "SELECT * FROM feedback WHERE comments LIKE ?");
                        ps.setString(1, "%" + keyword + "%");
                        ResultSet rs2 = ps.executeQuery();
                        
                        boolean hasFeedback = false;
                        while (rs2.next()) {
                            hasFeedback = true;
                            int rating = rs2.getInt("rating");
                    %>
                            <div class="feedback-card">
                                <div class="feedback-header">
                                    <span class="feedback-student">
                                        <i class="fas fa-user"></i> <%= rs2.getString("student") %>
                                    </span>
                                    <span class="feedback-category">
                                        <%= rs2.getString("category") %>
                                    </span>
                                </div>
                                <div class="feedback-comment">
                                    <%= rs2.getString("comments") %>
                                </div>
                                <div class="feedback-rating">
                                    <% for (int i = 1; i <= 5; i++) { %>
                                        <i class="fas <%= i <= rating ? "fa-star" : "fa-star-half-alt" %>"></i>
                                    <% } %>
                                    <span style="color: #666; font-size: 14px; margin-left: 5px;">
                                        (<%= rating %>/5)
                                    </span>
                                </div>
                            </div>
                    <%
                        }
                        
                        if (!hasFeedback) {
                    %>
                            <div class="no-results">
                                <i class="fas fa-info-circle"></i> No matching feedback found
                            </div>
                    <%
                        }
                        rs2.close();
                        ps.close();
                    %>
                <% } %>
            <% } else { %>
                <div class="no-results">
                    <i class="fas fa-search" style="font-size: 24px; margin-bottom: 10px;"></i>
                    <p>Enter search terms to find matching FAQs and feedback</p>
                </div>
            <% } %>
        </div>
    </div>
    
    <div class="back-link">
        <a href="<%= isAdmin ? "adminDashboard.jsp" : "dashboard.jsp" %>">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
</body>
</html>
<%
    conn.close();
%>