<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*" %>
<%@ page import="javax.servlet.*" %>
<%@ page import="javax.servlet.http.*" %>

<%
    String message = "";

    // Redirect if not logged in
    if (session == null || session.getAttribute("username") == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    if ("POST".equalsIgnoreCase(request.getMethod())) {
        String category = request.getParameter("category");
        String timeSlot = request.getParameter("timeSlot");
        String student = session.getAttribute("username").toString();

        try {
            Class.forName("org.sqlite.JDBC");

            // ✅ Consistent database path
            String dbPath = application.getRealPath("/WEB-INF/database/assist_user_data.db");
            System.out.println("Booking - DB Path: " + dbPath);

            Connection con = DriverManager.getConnection("jdbc:sqlite:" + dbPath);

            // ✅ Ensure the appointments table exists
            Statement st = con.createStatement();
            st.executeUpdate("CREATE TABLE IF NOT EXISTS appointments (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "student TEXT NOT NULL," +
                "category TEXT NOT NULL," +
                "timeSlot TEXT NOT NULL," +
                "status TEXT NOT NULL DEFAULT 'Pending'," +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
            st.close();

            // ✅ Insert appointment
            String sql = "INSERT INTO appointments (student, category, timeSlot, status) VALUES (?, ?, ?, 'Pending')";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, student);
            stmt.setString(2, category);
            stmt.setString(3, timeSlot);

            int rows = stmt.executeUpdate();
            message = (rows > 0) ? "Session booked successfully!" : "Failed to book session.";

            stmt.close();
            con.close();
        } catch (Exception e) {
            message = "Error booking session: " + e.getMessage();
            e.printStackTrace();
        }
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Book Support Session - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .booking-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            overflow: hidden;
            animation: fadeIn 0.6s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .booking-header {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            background: var(--primary-color);
            color: white;
            padding: 25px;
            text-align: center;
        }
        
        .booking-header h2 {
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .booking-header p {
            opacity: 0.9;
            font-size: 14px;
        }
        
        .booking-form {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }
        
        .form-group select,
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            appearance: none;
        }
        
        .form-group select {
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 16px;
        }
        
        .form-group select:focus,
        .form-group input:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(72, 149, 239, 0.2);
            outline: none;
        }
        
        .btn-submit {
            width: 100%;
            padding: 14px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
            font-weight: 500;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .btn-submit:hover {
            background: linear-gradient(to right, var(--secondary-color), var(--primary-color));
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .message {
            padding: 12px;
            border-radius: 8px;
            margin: 20px 0;
            font-size: 14px;
            text-align: center;
            animation: slideDown 0.4s ease-out;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .success-message {
            background-color: #e6ffed;
            color: var(--success-color);
            border: 1px solid #b7eb8f;
        }
        
        .error-message {
            background-color: #ffebee;
            color: var(--error-color);
            border: 1px solid #ffcdd2;
        }
        
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            transition: all 0.2s ease;
        }
        
        .back-link a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .back-link a i {
            margin-right: 5px;
        }
        
        .time-slot-suggestions {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 10px;
        }
        
        .time-slot-btn {
            padding: 8px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 6px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s ease;
            font-size: 13px;
        }
        
        .time-slot-btn:hover {
            border-color: var(--accent-color);
            color: var(--primary-color);
        }
        
        @media (max-width: 480px) {
            .time-slot-suggestions {
                grid-template-columns: 1fr;
            }
            
            .booking-form {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="booking-container">
        <div class="booking-header">
            <h2>Book Support Session</h2>
            <p>Schedule your appointment with our support team</p>
        </div>
        
        <div class="booking-form">
            <form method="post">
                <div class="form-group">
                    <label for="category">Support Category</label>
                    <select id="category" name="category" required>
                        <option value="">Select a category</option>
                        <option value="Mental Health">Mental Health Support</option>
                        <option value="Academic Guidance">Academic Guidance</option>
                        <option value="Financial Aid">Financial Aid Assistance</option>
                        <option value="Career Counseling">Career Counseling</option>
                        <option value="Health Services">Health Services</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="timeSlot">Preferred Time Slot</label>
                    <input type="text" id="timeSlot" name="timeSlot" placeholder="e.g., Monday 2:00 PM - 3:00 PM" required>
                    
                    <div class="time-slot-suggestions">
                        <div class="time-slot-btn" onclick="document.getElementById('timeSlot').value = 'Monday 10:00 AM - 11:00 AM'">Mon 10-11 AM</div>
                        <div class="time-slot-btn" onclick="document.getElementById('timeSlot').value = 'Tuesday 2:00 PM - 3:00 PM'">Tue 2-3 PM</div>
                        <div class="time-slot-btn" onclick="document.getElementById('timeSlot').value = 'Wednesday 11:00 AM - 12:00 PM'">Wed 11-12 PM</div>
                        <div class="time-slot-btn" onclick="document.getElementById('timeSlot').value = 'Thursday 3:00 PM - 4:00 PM'">Thu 3-4 PM</div>
                    </div>
                </div>
                
                <button type="submit" class="btn-submit">
                    <i class="fas fa-calendar-check"></i> Book Session
                </button>
            </form>
            
            <% if (!message.isEmpty()) { %>
                <div class="message <%= message.contains("successfully") ? "success-message" : "error-message" %>">
                    <i class="fas <%= message.contains("successfully") ? "fa-check-circle" : "fa-exclamation-circle" %>"></i>
                    <%= message %>
                </div>
            <% } %>
            
            <div class="back-link">
                <a href="dashboard.jsp"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            </div>
        </div>
    </div>

    <script>
        // Simple script to enhance the time slot input
        document.addEventListener('DOMContentLoaded', function() {
            const timeSlotInput = document.getElementById('timeSlot');
            
            // Focus the time slot input when clicking on suggested times
            document.querySelectorAll('.time-slot-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    timeSlotInput.focus();
                });
            });
        });
    </script>
</body>
</html>