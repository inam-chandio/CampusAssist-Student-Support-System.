<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<%
    String message = "";
    if ("POST".equalsIgnoreCase(request.getMethod())) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        try {
            Class.forName("org.sqlite.JDBC");
            String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
            Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);

            Statement stmt = conn.createStatement();
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS users (" +
                               "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                               "username TEXT NOT NULL UNIQUE, " +
                               "password TEXT NOT NULL, " +
                               "role TEXT NOT NULL DEFAULT 'student')");
            stmt.close();

            PreparedStatement ps = conn.prepareStatement("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, role);
            ps.executeUpdate();
            ps.close();
            conn.close();

            message = "Registration successful! You can now login.";

        } catch (SQLException e) {
            if (e.getMessage().contains("UNIQUE constraint failed")) {
                message = "Username already exists. Please choose a different username.";
            } else {
                message = "SQL Error: " + e.getMessage();
            }
        } catch (Exception e) {
            message = "Error: " + e.getMessage();
            e.printStackTrace();
        }
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Register - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
            --warning-color: #f0ad4e;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .register-container {
            display: flex;
            max-width: 1000px;
            width: 100%;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.6s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .register-illustration {
            flex: 1;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px;
            color: white;
        }
        
        .register-illustration img {
            width: 80%;
            max-width: 300px;
            margin-bottom: 30px;
        }
        
        .register-illustration h2 {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .register-illustration p {
            font-size: 16px;
            opacity: 0.9;
            text-align: center;
            line-height: 1.6;
        }
        
        .register-box {
            flex: 1;
            background: white;
            padding: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .register-header {
            margin-bottom: 30px;
            text-align: center;
        }
        
        .register-header h1 {
            color: var(--dark-color);
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .register-header p {
            color: #666;
            font-size: 14px;
        }
        
        .register-form .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .register-form label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            color: var(--dark-color);
            font-weight: 500;
        }
        
        .register-form input,
        .register-form select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 16px;
        }
        
        .register-form input:focus,
        .register-form select:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(72, 149, 239, 0.2);
            outline: none;
        }
        
        .register-form button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
            font-weight: 500;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .register-form button:hover {
            background: linear-gradient(to right, var(--secondary-color), var(--primary-color));
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .message {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
            animation: slideDown 0.4s ease-out;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .success-message {
            background-color: #e6ffed;
            color: var(--success-color);
            border: 1px solid #b7eb8f;
        }
        
        .error-message {
            background-color: #ffebee;
            color: var(--error-color);
            border: 1px solid #ffcdd2;
        }
        
        .role-description {
            margin-top: 5px;
            font-size: 12px;
            color: #666;
            line-height: 1.4;
        }
        
        .register-footer {
            margin-top: 25px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }
        
        .register-footer a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .register-footer a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
        }
        
        .divider::before, .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #eee;
        }
        
        .divider-text {
            padding: 0 10px;
            color: #999;
            font-size: 13px;
        }
        
        @media (max-width: 768px) {
            .register-container {
                flex-direction: column;
            }
            
            .register-illustration {
                padding: 30px 20px;
            }
            
            .register-box {
                padding: 30px;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-illustration">
            <img src="https://cdn-icons-png.flaticon.com/512/4400/4400628.png" alt="Registration Illustration">
            <h2>Join CampusAssist</h2>
            <p>Create your account to access all campus services and support systems in one place.</p>
        </div>
        
        <div class="register-box">
            <div class="register-header">
                <h1>Create Account</h1>
                <p>Fill in your details to get started</p>
            </div>
            
            <% if (!message.isEmpty()) { %>
                <div class="message <%= message.contains("successful") ? "success-message" : "error-message" %>">
                    <%= message %>
                </div>
            <% } %>
            
            <form class="register-form" method="post" action="register.jsp">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Choose a username" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Create a password" required>
                </div>
                
                <div class="form-group">
                    <label for="role">Account Type</label>
                    <select id="role" name="role" required>
                        <option value="">-- Select Account Type --</option>
                        <option value="student">Student</option>
                        <option value="counselor">Counselor</option>
                        <option value="admin">Administrator</option>
                    </select>
                    <div class="role-description">
                        <span id="role-description-text">Select your role to determine access level</span>
                    </div>
                </div>
                
                <button type="submit">Create Account</button>
            </form>
            
            <div class="divider">
                <span class="divider-text">OR</span>
            </div>
            
            <div class="register-footer">
                Already have an account? <a href="login.jsp">Sign in here</a>
            </div>
        </div>
    </div>

    <script>
        // Dynamic role description
        document.getElementById('role').addEventListener('change', function() {
            const description = document.getElementById('role-description-text');
            switch(this.value) {
                case 'student':
                    description.textContent = 'Access to appointment scheduling and campus services';
                    break;
                case 'counselor':
                    description.textContent = 'Access to student appointments and counseling tools';
                    break;
                case 'admin':
                    description.textContent = 'Full system access for administration and management';
                    break;
                default:
                    description.textContent = 'Select your role to determine access level';
            }
        });
    </script>
</body>
</html>