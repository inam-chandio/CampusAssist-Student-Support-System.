<%@ page session="true" %>
<%
    String role = (String) session.getAttribute("role");
    if (role == null || !role.equals("admin")) {
        response.sendRedirect("login.jsp");
        return;
    }
    
    String username = (String) session.getAttribute("username");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
            --warning-color: #f0ad4e;
            --sidebar-width: 250px;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: var(--dark-color);
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(to bottom, var(--primary-color), var(--secondary-color));
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
        }
        
        .sidebar-header h3 {
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .sidebar-header p {
            font-size: 13px;
            opacity: 0.8;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-menu li {
            position: relative;
        }
        
        .nav-menu li a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .nav-menu li a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .nav-menu li a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .nav-menu li.active a {
            background-color: rgba(255, 255, 255, 0.2);
        }
        
        .nav-menu li.active::before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 4px;
            background-color: white;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 30px;
            transition: all 0.3s ease;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .user-info {
            display: flex;
            align-items: center;
        }
        
        .user-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }
        
        .user-info .user-name {
            font-weight: 500;
        }
        
        .user-info .user-role {
            font-size: 12px;
            color: #666;
        }
        
        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .card-title {
            font-size: 16px;
            font-weight: 500;
            color: #666;
        }
        
        .card-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        
        .card-icon.appointments {
            background-color: #4361ee;
        }
        
        .card-icon.feedback {
            background-color: #4cc9f0;
        }
        
        .card-icon.faqs {
            background-color: #f72585;
        }
        
        .card-icon.users {
            background-color: #4895ef;
        }
        
        .card-value {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .card-footer {
            font-size: 12px;
            color: #666;
            display: flex;
            align-items: center;
        }
        
        .card-footer i {
            margin-right: 5px;
        }
        
        .positive {
            color: var(--success-color);
        }
        
        /* Recent Activity */
        .recent-activity {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 500;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }
        
        .section-title i {
            margin-right: 10px;
            color: var(--primary-color);
        }
        
        .activity-list {
            list-style: none;
        }
        
        .activity-item {
            display: flex;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(72, 149, 239, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: var(--accent-color);
        }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-title {
            font-weight: 500;
            margin-bottom: 5px;
        }
        
        .activity-time {
            font-size: 12px;
            color: #666;
        }
        
        /* Responsive Styles */
        @media (max-width: 768px) {
            .sidebar {
                width: 0;
                overflow: hidden;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>CampusAssist</h3>
            <p>Admin Dashboard</p>
        </div>
        
        <ul class="nav-menu">
            <li class="active">
                <a href="adminDashboard.jsp">
                    <i class="fas fa-tachometer-alt"></i>
                    Dashboard
                </a>
            </li>
            <li>
                <a href="manageAppointments.jsp">
                    <i class="fas fa-calendar-check"></i>
                    Appointments
                </a>
            </li>
            <li>
                <a href="manageFeedback.jsp">
                    <i class="fas fa-comment-alt"></i>
                    Feedback
                </a>
            </li>
            <li>
                <a href="manageFAQs.jsp">
                    <i class="fas fa-question-circle"></i>
                    FAQs
                </a>
            </li>
            <li>
                <a href="search.jsp">
                    <i class="fas fa-search"></i>
                    Search
                </a>
            </li>
            <li>
                <a href="logout.jsp">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Main Content Area -->
    <div class="main-content">
        <div class="header">
            <h1>Admin Dashboard</h1>
            <div class="user-info">
                <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="User">
                <div>
                    <div class="user-name"><%= username %></div>
                    <div class="user-role">Administrator</div>
                </div>
            </div>
        </div>
        
        <!-- Dashboard Cards -->
        <div class="dashboard-cards">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Appointments</div>
                    <div class="card-icon appointments">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                </div>
                <div class="card-value">24</div>
                <div class="card-footer">
                    <i class="fas fa-arrow-up positive"></i>
                    <span>5 new today</span>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Feedback</div>
                    <div class="card-icon feedback">
                        <i class="fas fa-comment-alt"></i>
                    </div>
                </div>
                <div class="card-value">18</div>
                <div class="card-footer">
                    <i class="fas fa-arrow-up positive"></i>
                    <span>3 new today</span>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <div class="card-title">FAQs</div>
                    <div class="card-icon faqs">
                        <i class="fas fa-question-circle"></i>
                    </div>
                </div>
                <div class="card-value">42</div>
                <div class="card-footer">
                    <i class="fas fa-arrow-down"></i>
                    <span>2 updated</span>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Users</div>
                    <div class="card-icon users">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <div class="card-value">156</div>
                <div class="card-footer">
                    <i class="fas fa-arrow-up positive"></i>
                    <span>8 new this week</span>
                </div>
            </div>
        </div>
        
        <!-- Recent Activity Section -->
        <div class="recent-activity">
            <h3 class="section-title">
                <i class="fas fa-history"></i>
                Recent Activity
            </h3>
            
            <ul class="activity-list">
                <li class="activity-item">
                    <div class="activity-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-title">New appointment scheduled</div>
                        <div class="activity-time">10 minutes ago</div>
                    </div>
                </li>
                
                <li class="activity-item">
                    <div class="activity-icon">
                        <i class="fas fa-comment-alt"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-title">Feedback submitted by student</div>
                        <div class="activity-time">25 minutes ago</div>
                    </div>
                </li>
                
                <li class="activity-item">
                    <div class="activity-icon">
                        <i class="fas fa-user-plus"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-title">New counselor registered</div>
                        <div class="activity-time">1 hour ago</div>
                    </div>
                </li>
                
                <li class="activity-item">
                    <div class="activity-icon">
                        <i class="fas fa-question-circle"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-title">FAQ updated</div>
                        <div class="activity-time">2 hours ago</div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</body>
</html>