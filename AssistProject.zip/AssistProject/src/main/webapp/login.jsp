<%@ page import="java.sql.*" %>
<%@ page import="javax.servlet.http.*,javax.servlet.*" %>
<%@ page import="java.sql.*" %>
<%@ page import="javax.servlet.http.*,javax.servlet.*" %>
<%
    String message = "";
    if ("POST".equalsIgnoreCase(request.getMethod())) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Class.forName("org.sqlite.JDBC");

            // Get full path to your SQLite DB inside WEB-INF
            String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
            Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);

            Statement stmt = conn.createStatement();

            // Create tables if not exists
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE, " +
                "password TEXT NOT NULL, " +
                "role TEXT NOT NULL DEFAULT 'student')");

            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS appointments (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "student TEXT NOT NULL, " +
                "category TEXT NOT NULL, " +
                "timeSlot TEXT NOT NULL, " +
                "status TEXT NOT NULL DEFAULT 'Pending', " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS feedback (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "student TEXT NOT NULL, " +
                "category TEXT NOT NULL, " +
                "comments TEXT NOT NULL, " +
                "rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5), " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS faqs (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "question TEXT NOT NULL, " +
                "answer TEXT NOT NULL, " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

            // Insert default admin
            PreparedStatement checkAdmin = conn.prepareStatement("SELECT COUNT(*) FROM users WHERE username = ?");
            checkAdmin.setString(1, "admin");
            ResultSet rsAdmin = checkAdmin.executeQuery();
            if (rsAdmin.next() && rsAdmin.getInt(1) == 0) {
                PreparedStatement insertAdmin = conn.prepareStatement("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
                insertAdmin.setString(1, "admin");
                insertAdmin.setString(2, "admin123");
                insertAdmin.setString(3, "admin");
                insertAdmin.executeUpdate();
                insertAdmin.close();
            }
            rsAdmin.close();
            checkAdmin.close();

            // Login check
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?");
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String role = rs.getString("role");
                session.setAttribute("userId", rs.getInt("id"));
                session.setAttribute("username", rs.getString("username"));
                session.setAttribute("role", role);
                rs.close();
                ps.close();
                conn.close();

                if ("admin".equals(role)) {
                    response.sendRedirect("adminDashboard.jsp");
                } else {
                    response.sendRedirect("dashboard.jsp");
                }
                return;
            } else {
                message = "Invalid username or password.";
            }

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            message = "Error: " + e.getMessage();
            e.printStackTrace();
        }
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Login - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
            --warning-color: #f0ad4e;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .login-container {
            display: flex;
            max-width: 1000px;
            width: 100%;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.6s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .login-illustration {
            flex: 1;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px;
            color: white;
        }
        
        .login-illustration img {
            width: 80%;
            max-width: 300px;
            margin-bottom: 30px;
        }
        
        .login-illustration h2 {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .login-illustration p {
            font-size: 16px;
            opacity: 0.9;
            text-align: center;
            line-height: 1.6;
        }
        
        .login-box {
            flex: 1;
            background: white;
            padding: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .login-header {
            margin-bottom: 30px;
            text-align: center;
        }
        
        .login-header h1 {
            color: var(--dark-color);
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .login-header p {
            color: #666;
            font-size: 14px;
        }
        
        .login-form .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .login-form label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            color: var(--dark-color);
            font-weight: 500;
        }
        
        .login-form input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .login-form input:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(72, 149, 239, 0.2);
            outline: none;
        }
        
        .login-form button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
            font-weight: 500;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .login-form button:hover {
            background: linear-gradient(to right, var(--secondary-color), var(--primary-color));
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .message {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
            animation: slideDown 0.4s ease-out;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .error-message {
            background-color: #ffebee;
            color: var(--error-color);
            border: 1px solid #ffcdd2;
        }
        
        .default-credentials {
            background-color: #e3f2fd;
            border-left: 4px solid var(--accent-color);
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 0 8px 8px 0;
        }
        
        .default-credentials h4 {
            color: var(--dark-color);
            font-size: 14px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
        }
        
        .default-credentials h4 svg {
            margin-right: 8px;
        }
        
        .default-credentials p {
            font-size: 13px;
            color: #555;
            line-height: 1.5;
        }
        
        .default-credentials strong {
            color: var(--primary-color);
        }
        
        .login-footer {
            margin-top: 25px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }
        
        .login-footer a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .login-footer a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
        }
        
        .divider::before, .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #eee;
        }
        
        .divider-text {
            padding: 0 10px;
            color: #999;
            font-size: 13px;
        }
        
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
            }
            
            .login-illustration {
                padding: 30px 20px;
            }
            
            .login-box {
                padding: 30px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-illustration">
            <img src="https://cdn-icons-png.flaticon.com/512/4775/4775990.png" alt="Campus Assistance">
            <h2>Welcome to CampusAssist</h2>
            <p>Your one-stop solution for campus services, appointments, and academic support.</p>
        </div>
        
        <div class="login-box">
            <div class="login-header">
                <h1>Sign In</h1>
                <p>Access your account to manage appointments and services</p>
            </div>
            
            <% if (!message.isEmpty()) { %>
                <div class="message error-message"><%= message %></div>
            <% } %>
            
            <div class="default-credentials">
                <h4>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12 16V12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12 8H12.01" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Default Credentials
                </h4>
                <p>Admin: <strong>admin</strong> / <strong>admin123</strong><br>
                Student: <i>(register to create student account)</i></p>
            </div>
            
            <form class="login-form" method="post" action="login.jsp">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
                
                <button type="submit">Sign In</button>
            </form>
            
            <div class="divider">
                <span class="divider-text">OR</span>
            </div>
            
            <div class="login-footer">
                Don't have an account? <a href="register.jsp">Create account</a>
            </div>
        </div>
    </div>
</body>
</html>