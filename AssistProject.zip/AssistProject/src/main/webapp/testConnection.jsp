<%@ page import="java.sql.*, javax.servlet.*, javax.servlet.http.*" %>
<%
    String message = "";
    try {
        Class.forName("org.sqlite.JDBC"); // Load the SQLite JDBC driver
        Connection con = DriverManager.getConnection("jdbc:sqlite:/mnt/data/campusassist.db");

        if (con != null) {
            message = "Connection to campusassist.db established successfully!";
            con.close();
        } else {
            message = "Failed to connect to the database.";
        }
    } catch (Exception e) {
        message = "Connection error: " + e.getMessage();
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Test DB Connection</title>
</head>
<body>
    <h2>Database Connection Status</h2>
    <p><%= message %></p>
    <a href="index.jsp">Back to Home</a>
</body>
</html>
