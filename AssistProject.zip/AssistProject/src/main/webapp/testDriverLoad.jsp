<%@ page import="java.sql.*" %>
<%
    try {
        Class.forName("org.sqlite.JDBC");
        out.println("SQLite JDBC driver loaded successfully!");
    } catch (ClassNotFoundException e) {
        out.println("Failed to load SQLite JDBC driver: " + e.getMessage());
    }
%>
