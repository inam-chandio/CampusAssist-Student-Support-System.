<%@ page import="java.sql.*, javax.servlet.http.*, javax.servlet.*" %>
<%
    // Redirect if not logged in
    if (session == null || session.getAttribute("username") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    
    String username = session.getAttribute("username").toString();
    String role = session.getAttribute("role") != null ? session.getAttribute("role").toString() : "student";
%>
<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
            --sidebar-width: 280px;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: var(--dark-color);
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(to bottom, var(--primary-color), var(--secondary-color));
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            padding: 30px 0;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
        }
        
        .sidebar-header h3 {
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .sidebar-header p {
            font-size: 14px;
            opacity: 0.8;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-menu li {
            position: relative;
        }
        
        .nav-menu li a {
            display: flex;
            align-items: center;
            padding: 14px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .nav-menu li a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .nav-menu li a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
            font-size: 18px;
        }
        
        .nav-menu li.active a {
            background-color: rgba(255, 255, 255, 0.2);
        }
        
        .nav-menu li.active::before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 4px;
            background-color: white;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 40px;
            transition: all 0.3s ease;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .welcome-message {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        
        .welcome-message h2 {
            font-size: 24px;
            margin-bottom: 15px;
            color: var(--primary-color);
        }
        
        .welcome-message p {
            color: #666;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        
        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .action-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .action-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: rgba(72, 149, 239, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: var(--primary-color);
            font-size: 24px;
        }
        
        .action-title {
            font-weight: 500;
            margin-bottom: 10px;
            font-size: 18px;
        }
        
        .action-description {
            color: #666;
            font-size: 14px;
            margin-bottom: 15px;
        }
        
        .action-btn {
            display: inline-block;
            padding: 8px 20px;
            background: var(--primary-color);
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.2s ease;
        }
        
        .action-btn:hover {
            background: var(--secondary-color);
        }
        
        /* Upcoming Appointments */
        .upcoming-appointments {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .section-title {
            display: flex;
            align-items: center;
            font-size: 20px;
            font-weight: 500;
            margin-bottom: 20px;
            color: var(--dark-color);
        }
        
        .section-title i {
            margin-right: 10px;
            color: var(--primary-color);
        }
        
        .appointment-list {
            list-style: none;
        }
        
        .appointment-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        .appointment-item:last-child {
            border-bottom: none;
        }
        
        .appointment-details h4 {
            font-weight: 500;
            margin-bottom: 5px;
        }
        
        .appointment-details p {
            color: #666;
            font-size: 14px;
        }
        
        .appointment-status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-confirmed {
            background-color: #d4edda;
            color: #155724;
        }
        
        .no-appointments {
            text-align: center;
            padding: 20px;
            color: #666;
        }
        
        /* Responsive Styles */
        @media (max-width: 768px) {
            .sidebar {
                width: 0;
                overflow: hidden;
            }
            
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            
            .quick-actions {
                grid-template-columns: 1fr;
            }
            
            .header {
                flex-direction: column;
                align-items: flex-start;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>CampusAssist</h3>
            <p>Student Dashboard</p>
        </div>
        
        <ul class="nav-menu">
            <li class="active">
                <a href="dashboard.jsp">
                    <i class="fas fa-tachometer-alt"></i>
                    Dashboard
                </a>
            </li>
            <li>
                <a href="bookSession.jsp">
                    <i class="fas fa-calendar-plus"></i>
                    Book Session
                </a>
            </li>
            <li>
                <a href="viewAppointments.jsp">
                    <i class="fas fa-calendar-check"></i>
                    My Appointments
                </a>
            </li>
            <li>
                <a href="feedback.jsp">
                    <i class="fas fa-comment-alt"></i>
                    Give Feedback
                </a>
            </li>
            <li>
                <a href="browseServices.jsp">
                    <i class="fas fa-search"></i>
                    Browse Services
                </a>
            </li>
            <li>
                <a href="logout.jsp">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Main Content Area -->
    <div class="main-content">
        <div class="header">
            <h1>Student Dashboard</h1>
            <div class="user-info">
                <span>Welcome, <strong><%= username %></strong> (<%= role %>)</span>
            </div>
        </div>
        
        <!-- Welcome Message -->
        <div class="welcome-message">
            <h2>Hello, <%= username %>!</h2>
            <p>Welcome back to your CampusAssist dashboard. Here you can book support sessions, manage your appointments, and access all the campus services you need. We're here to help you succeed in your academic journey.</p>
        </div>
        
        <!-- Quick Actions -->
        <div class="quick-actions">
            <div class="action-card">
                <div class="action-icon">
                    <i class="fas fa-calendar-plus"></i>
                </div>
                <h3 class="action-title">Book Session</h3>
                <p class="action-description">Schedule a new support session with our team</p>
                <a href="bookSession.jsp" class="action-btn">Book Now</a>
            </div>
            
            <div class="action-card">
                <div class="action-icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <h3 class="action-title">My Appointments</h3>
                <p class="action-description">View and manage your scheduled sessions</p>
                <a href="viewAppointments.jsp" class="action-btn">View All</a>
            </div>
            
            <div class="action-card">
                <div class="action-icon">
                    <i class="fas fa-comment-alt"></i>
                </div>
                <h3 class="action-title">Give Feedback</h3>
                <p class="action-description">Share your experience with our services</p>
                <a href="feedback.jsp" class="action-btn">Provide Feedback</a>
            </div>
            
            <div class="action-card">
                <div class="action-icon">
                    <i class="fas fa-search"></i>
                </div>
                <h3 class="action-title">Browse Services</h3>
                <p class="action-description">Explore all available campus support services</p>
                <a href="browseServices.jsp" class="action-btn">Explore</a>
            </div>
        </div>
        
        <!-- Upcoming Appointments -->
        <div class="upcoming-appointments">
            <h3 class="section-title">
                <i class="fas fa-clock"></i>
                Upcoming Appointments
            </h3>
            
            <ul class="appointment-list">
                <!-- Sample appointment - in a real app, you would loop through database results -->
                <li class="appointment-item">
                    <div class="appointment-details">
                        <h4>Mental Health Support</h4>
                        <p>Tomorrow, 2:00 PM - 3:00 PM</p>
                    </div>
                    <div class="appointment-status status-confirmed">
                        Confirmed
                    </div>
                </li>
                
                <li class="appointment-item">
                    <div class="appointment-details">
                        <h4>Academic Guidance</h4>
                        <p>Friday, 10:00 AM - 11:00 AM</p>
                    </div>
                    <div class="appointment-status status-pending">
                        Pending
                    </div>
                </li>
                
                <!-- This would be replaced with dynamic content from your database -->
                <!-- <%
                    try {
                        Class.forName("org.sqlite.JDBC");
                        String dbPath = application.getRealPath("/WEB-INF/database/assist_user_data.db");
                        Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
                        
                        String sql = "SELECT * FROM appointments WHERE student = ? AND status != 'Completed' ORDER BY timeSlot ASC LIMIT 3";
                        PreparedStatement stmt = conn.prepareStatement(sql);
                        stmt.setString(1, username);
                        ResultSet rs = stmt.executeQuery();
                        
                        if (!rs.isBeforeFirst()) {
                            out.println("<div class='no-appointments'>You have no upcoming appointments</div>");
                        } else {
                            while (rs.next()) {
                                out.println("<li class='appointment-item'>");
                                out.println("<div class='appointment-details'>");
                                out.println("<h4>" + rs.getString("category") + "</h4>");
                                out.println("<p>" + rs.getString("timeSlot") + "</p>");
                                out.println("</div>");
                                out.println("<div class='appointment-status status-" + rs.getString("status").toLowerCase() + "'>");
                                out.println(rs.getString("status"));
                                out.println("</div>");
                                out.println("</li>");
                            }
                        }
                        
                        rs.close();
                        stmt.close();
                        conn.close();
                    } catch (Exception e) {
                        out.println("<div class='no-appointments'>Error loading appointments</div>");
                    }
                %> -->
            </ul>
        </div>
    </div>
</body>
</html>