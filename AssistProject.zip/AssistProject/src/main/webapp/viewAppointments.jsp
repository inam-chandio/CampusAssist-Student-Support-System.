<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*, javax.servlet.http.*, javax.servlet.*" %>
<%
    if (session == null || session.getAttribute("username") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    String username = session.getAttribute("username").toString();
%>
<!DOCTYPE html>
<html>
<head>
    <title>Your Appointments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
            color: #495057;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .status-pending {
            color: #856404;
            background-color: #fff3cd;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        .status-approved {
            color: #155724;
            background-color: #d4edda;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        .status-cancelled {
            color: #721c24;
            background-color: #f8d7da;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        .no-appointments {
            text-align: center;
            color: #6c757d;
            padding: 40px;
            font-style: italic;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }
        .back-link a:hover {
            text-decoration: underline;
        }
        .error-message {
            color: #721c24;
            background-color: #f8d7da;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Your Appointments</h2>
        <%
            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;
            boolean hasAppointments = false;
            String errorMessage = "";

            try {
                Class.forName("org.sqlite.JDBC");
                String dbPath = application.getRealPath("/WEB-INF/database/assist_user_data.db");
                con = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
                
                stmt = con.prepareStatement("SELECT category, timeSlot, status, created_at FROM appointments WHERE student = ? ORDER BY created_at DESC");
                stmt.setString(1, username);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    hasAppointments = true;
        %>
        
        <table>
            <thead>
                <tr>
                    <th>Support Category</th>
                    <th>Time Slot</th>
                    <th>Status</th>
                    <th>Requested On</th>
                </tr>
            </thead>
            <tbody>
                <%
                    do {
                        String status = rs.getString("status");
                        String statusClass = "status-pending";
                        if ("Approved".equalsIgnoreCase(status)) statusClass = "status-approved";
                        else if ("Cancelled".equalsIgnoreCase(status)) statusClass = "status-cancelled";
                %>
                <tr>
                    <td><%= rs.getString("category") %></td>
                    <td><%= rs.getString("timeSlot") %></td>
                    <td><span class="<%= statusClass %>"><%= status %></span></td>
                    <td><%= rs.getString("created_at") != null ? rs.getString("created_at").substring(0, 16) : "N/A" %></td>
                </tr>
                <%
                    } while (rs.next());
                %>
            </tbody>
        </table>
        <%
                } else {
        %>
        
        <div class="no-appointments">
            You haven't booked any appointments yet.<br>
            <a href="bookSession.jsp" style="color: #007bff;">Book your first session</a>
        </div>
        <%
                }
            } catch (Exception e) {
                errorMessage = "Error fetching appointments: " + e.getMessage();
                e.printStackTrace();
            } finally {
                try { if (rs != null) rs.close(); } catch (Exception ignored) {}
                try { if (stmt != null) stmt.close(); } catch (Exception ignored) {}
                try { if (con != null) con.close(); } catch (Exception ignored) {}
            }

            if (!errorMessage.isEmpty()) {
        %>
        <div class="error-message"><%= errorMessage %></div>
        <%
            }
        %>
        <div class="back-link">
            <a href="dashboard.jsp">← Back to Dashboard</a>
        </div>
    </div>
</body>
</html>