<%@ page import="java.sql.*" %>
<%@ page session="true" %>
<%
    // Authentication check
    if (!"admin".equals(session.getAttribute("role"))) {
        response.sendRedirect("login.jsp");
        return;
    }

    String message = "";
    String editId = request.getParameter("editId");
    String editQuestion = "";
    String editAnswer = "";
    boolean isEditMode = false;
    
    // Handle FAQ deletion
    if ("POST".equalsIgnoreCase(request.getMethod()) && request.getParameter("deleteId") != null) {
        String deleteId = request.getParameter("deleteId");
        
        try {
            Class.forName("org.sqlite.JDBC");
            String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
            Connection deleteConn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
            
            PreparedStatement deleteStmt = deleteConn.prepareStatement(
                "DELETE FROM faqs WHERE id = ?");
            deleteStmt.setInt(1, Integer.parseInt(deleteId));
            
            int deleted = deleteStmt.executeUpdate();
            message = (deleted > 0) ? 
                "<i class='fas fa-check-circle'></i> FAQ deleted successfully!" : 
                "<i class='fas fa-exclamation-circle'></i> FAQ not found.";
            
            deleteStmt.close();
            deleteConn.close();
        } catch (Exception e) {
            message = "<i class='fas fa-times-circle'></i> Error deleting FAQ: " + e.getMessage();
        }
    }

    // Handle new FAQ addition
    if ("POST".equalsIgnoreCase(request.getMethod()) && request.getParameter("newQuestion") != null && !isEditMode) {
        String newQuestion = request.getParameter("newQuestion");
        String newAnswer = request.getParameter("newAnswer");
        
        try {
            Class.forName("org.sqlite.JDBC");
            String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
            Connection insertConn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
            
            // Ensure table exists
            Statement createStmt = insertConn.createStatement();
            createStmt.executeUpdate("CREATE TABLE IF NOT EXISTS faqs (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "question TEXT NOT NULL," +
                "answer TEXT NOT NULL," +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
            createStmt.close();
            
            PreparedStatement insertStmt = insertConn.prepareStatement(
                "INSERT INTO faqs (question, answer) VALUES (?, ?)");
            insertStmt.setString(1, newQuestion);
            insertStmt.setString(2, newAnswer);
            
            int inserted = insertStmt.executeUpdate();
            message = (inserted > 0) ? 
                "<i class='fas fa-check-circle'></i> FAQ added successfully!" : 
                "<i class='fas fa-exclamation-circle'></i> Failed to add FAQ.";
            
            insertStmt.close();
            insertConn.close();
        } catch (Exception e) {
            message = "<i class='fas fa-times-circle'></i> Error adding FAQ: " + e.getMessage();
        }
    }
    
    // Handle FAQ update
    if ("POST".equalsIgnoreCase(request.getMethod()) && request.getParameter("editQuestion") != null && editId != null) {
        String updatedQuestion = request.getParameter("editQuestion");
        String updatedAnswer = request.getParameter("editAnswer");
        
        try {
            Class.forName("org.sqlite.JDBC");
            String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
            Connection updateConn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
            
            PreparedStatement updateStmt = updateConn.prepareStatement(
                "UPDATE faqs SET question = ?, answer = ? WHERE id = ?");
            updateStmt.setString(1, updatedQuestion);
            updateStmt.setString(2, updatedAnswer);
            updateStmt.setInt(3, Integer.parseInt(editId));
            
            int updated = updateStmt.executeUpdate();
            message = (updated > 0) ? 
                "<i class='fas fa-check-circle'></i> FAQ updated successfully!" : 
                "<i class='fas fa-exclamation-circle'></i> FAQ not found.";
            
            updateStmt.close();
            updateConn.close();
            
            // Reset edit mode
            editId = null;
            isEditMode = false;
        } catch (Exception e) {
            message = "<i class='fas fa-times-circle'></i> Error updating FAQ: " + e.getMessage();
        }
    }
    
    // Load FAQ data if in edit mode
    if (editId != null && !"POST".equalsIgnoreCase(request.getMethod())) {
        try {
            Class.forName("org.sqlite.JDBC");
            String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
            Connection editConn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
            
            PreparedStatement editStmt = editConn.prepareStatement(
                "SELECT question, answer FROM faqs WHERE id = ?");
            editStmt.setInt(1, Integer.parseInt(editId));
            
            ResultSet editRs = editStmt.executeQuery();
            if (editRs.next()) {
                editQuestion = editRs.getString("question");
                editAnswer = editRs.getString("answer");
                isEditMode = true;
            } else {
                message = "<i class='fas fa-exclamation-circle'></i> FAQ not found.";
            }
            
            editRs.close();
            editStmt.close();
            editConn.close();
        } catch (Exception e) {
            message = "<i class='fas fa-times-circle'></i> Error loading FAQ: " + e.getMessage();
        }
    }

    // Database connection for listing FAQs
    Class.forName("org.sqlite.JDBC");
    String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
    Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    
    // Ensure table exists
    Statement createStmt = conn.createStatement();
    createStmt.executeUpdate("CREATE TABLE IF NOT EXISTS faqs (" +
        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
        "question TEXT NOT NULL," +
        "answer TEXT NOT NULL," +
        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
    createStmt.close();
    
    Statement stmt = conn.createStatement();
    ResultSet rs = stmt.executeQuery("SELECT * FROM faqs ORDER BY created_at DESC");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Manage FAQs - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* All your original beautiful CSS remains exactly the same */
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: var(--dark-color);
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .message {
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            font-size: 14px;
            display: flex;
            align-items: center;
            animation: slideDown 0.4s ease-out;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .message-success {
            background-color: #e6ffed;
            color: var(--success-color);
            border: 1px solid #b7eb8f;
        }
        
        .message-error {
            background-color: #ffebee;
            color: var(--error-color);
            border: 1px solid #ffcdd2;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
            transform: translateY(-2px);
        }
        
        .btn i {
            margin-right: 8px;
        }
        
        .add-faq-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        
        .add-faq-card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: var(--primary-color);
            display: flex;
            align-items: center;
        }
        
        .add-faq-card h2 i {
            margin-right: 10px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 14px;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
        }
        
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .faqs-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .faqs-table th {
            background: var(--primary-color);
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 500;
        }
        
        .faqs-table td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .faqs-table tr:last-child td {
            border-bottom: none;
        }
        
        .faqs-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .faqs-table tr:hover {
            background-color: #f1f1f1;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
        }
        
        .action-btn i {
            margin-right: 5px;
        }
        
        .edit-btn {
            background: #17a2b8;
            color: white;
        }
        
        .edit-btn:hover {
            background: #138496;
        }
        
        .delete-btn {
            background: #dc3545;
            color: white;
        }
        
        .delete-btn:hover {
            background: #c82333;
        }
        
        .no-faqs {
            text-align: center;
            padding: 30px;
            color: #666;
            font-style: italic;
        }
        
        .back-link {
            margin-top: 30px;
        }
        
        .back-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            transition: all 0.2s ease;
        }
        
        .back-link a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .back-link a i {
            margin-right: 8px;
        }
        
        @media (max-width: 768px) {
            .faqs-table {
                display: block;
                overflow-x: auto;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 5px;
            }
        }
        
        /* Only adding these minimal styles for the edit form */
        .edit-form-container {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            border-left: 4px solid var(--accent-color);
        }
        
        .form-actions {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>FAQs Management</h1>
            <a href="adminDashboard.jsp" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <% if (!message.isEmpty()) { %>
            <div class="message <%= message.contains("successfully") ? "message-success" : "message-error" %>">
                <%= message %>
            </div>
        <% } %>
        
        <!-- Edit FAQ Form (shown only in edit mode) -->
        <% if (isEditMode) { %>
            <div class="edit-form-container">
                <h2><i class="fas fa-edit"></i> Edit FAQ</h2>
                
                <form method="post">
                    <input type="hidden" name="editId" value="<%= editId %>">
                    
                    <div class="form-group">
                        <label for="editQuestion">Question</label>
                        <input type="text" id="editQuestion" name="editQuestion" 
                               value="<%= editQuestion %>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="editAnswer">Answer</label>
                        <textarea id="editAnswer" name="editAnswer" required><%= editAnswer %></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update FAQ
                        </button>
                        <a href="manageFAQs.jsp" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        <% } else { %>
            <!-- Add FAQ Card (shown only when not in edit mode) -->
            <div class="add-faq-card">
                <h2><i class="fas fa-plus-circle"></i> Add New FAQ</h2>
                
                <form method="post">
                    <div class="form-group">
                        <label for="newQuestion">Question</label>
                        <input type="text" id="newQuestion" name="newQuestion" 
                               placeholder="Enter the question" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="newAnswer">Answer</label>
                        <textarea id="newAnswer" name="newAnswer" 
                                  placeholder="Enter the answer" required></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Add FAQ
                    </button>
                </form>
            </div>
        <% } %>
        
        <!-- FAQs Table -->
        <table class="faqs-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Question</th>
                    <th>Answer</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <% 
                boolean hasData = false;
                while (rs.next()) { 
                    hasData = true;
                %>
                    <tr>
                        <td><%= rs.getInt("id") %></td>
                        <td><%= rs.getString("question") %></td>
                        <td><%= rs.getString("answer") %></td>
                        <td>
                            <div class="action-buttons">
                                <a href="manageFAQs.jsp?editId=<%= rs.getInt("id") %>" class="action-btn edit-btn">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="deleteId" value="<%= rs.getInt("id") %>">
                                                                        <button type="submit" class="action-btn delete-btn" 
                                            onclick="return confirm('Are you sure you want to delete this FAQ?')">
                                        <i class="fas fa-trash-alt"></i> Delete
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <% } %>
                
                <% if (!hasData) { %>
                    <tr>
                        <td colspan="4" class="no-faqs">
                            <i class="fas fa-info-circle"></i> No FAQs found in the system.
                        </td>
                    </tr>
                <% } %>
            </tbody>
        </table>
        
        <div class="back-link">
            <a href="adminDashboard.jsp"><i class="fas fa-arrow-left"></i> Back to Admin Dashboard</a>
        </div>
    </div>

    <script>
        // Small enhancement to make the UI more interactive
        document.addEventListener('DOMContentLoaded', function() {
            // Focus on the first input field when in edit mode
            <% if (isEditMode) { %>
                document.getElementById('editQuestion').focus();
            <% } else { %>
                document.getElementById('newQuestion').focus();
            <% } %>
            
            // Smooth scroll to the form after edit click
            const urlParams = new URLSearchParams(window.location.search);
            if(urlParams.has('editId')) {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            }
        });
    </script>
</body>
</html>
<%
    // Close database resources
    if (rs != null) rs.close();
    if (stmt != null) stmt.close();
    if (conn != null) conn.close();
%>