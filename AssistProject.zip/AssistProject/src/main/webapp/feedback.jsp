<%@ page import="java.sql.*, javax.servlet.http.*, javax.servlet.*" %>
<%
    // Redirect if not logged in
    if (session == null || session.getAttribute("username") == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    String message = "";
    if ("POST".equalsIgnoreCase(request.getMethod())) {
        String category = request.getParameter("category");
        String comments = request.getParameter("comments");
        String rating = request.getParameter("rating");
        String student = session.getAttribute("username").toString();

        try {
            Class.forName("org.sqlite.JDBC");
            // CORRECTED: Use consistent database path
            String dbPath = application.getRealPath("/WEB-INF/assist_user_data.db");
            Connection con = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
            
            // Ensure feedback table exists
            Statement st = con.createStatement();
            st.executeUpdate("CREATE TABLE IF NOT EXISTS feedback (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "student TEXT NOT NULL," +
                "category TEXT NOT NULL," +
                "comments TEXT NOT NULL," +
                "rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5)," +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
            st.close();
            
            PreparedStatement stmt = con.prepareStatement("INSERT INTO feedback (student, category, comments, rating) VALUES (?, ?, ?, ?)");
            stmt.setString(1, student);
            stmt.setString(2, category);
            stmt.setString(3, comments);
            stmt.setInt(4, Integer.parseInt(rating));
            stmt.executeUpdate();
            stmt.close();
            con.close();
            message = "Thank you for your feedback!";
        } catch (Exception e) {
            message = "Error submitting feedback: " + e.getMessage();
            e.printStackTrace();
        }
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Give Feedback - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .feedback-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            overflow: hidden;
            animation: fadeIn 0.6s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .feedback-header {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            background: var(--primary-color);
            color: white;
            padding: 25px;
            text-align: center;
        }
        
        .feedback-header h2 {
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .feedback-header p {
            opacity: 0.9;
            font-size: 14px;
        }
        
        .feedback-form {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }
        
        .form-group select,
        .form-group textarea,
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }
        
        .form-group select {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 16px;
        }
        
        .form-group textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .form-group select:focus,
        .form-group textarea:focus,
        .form-group input:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(72, 149, 239, 0.2);
            outline: none;
        }
        
        .rating-container {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }
        
        .rating-option {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
        }
        
        .rating-radio {
            display: none;
        }
        
        .rating-star {
            width: 40px;
            height: 40px;
            background-color: #f0f0f0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ccc;
            font-size: 18px;
            transition: all 0.2s ease;
        }
        
        .rating-radio:checked + .rating-star {
            background-color: #ffc107;
            color: #ff9800;
        }
        
        .rating-label {
            margin-top: 5px;
            font-size: 12px;
            color: #666;
        }
        
        .btn-submit {
            width: 100%;
            padding: 14px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
            font-weight: 500;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .btn-submit:hover {
            background: linear-gradient(to right, var(--secondary-color), var(--primary-color));
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .message {
            padding: 12px;
            border-radius: 8px;
            margin: 20px 0;
            font-size: 14px;
            text-align: center;
            animation: slideDown 0.4s ease-out;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .success-message {
            background-color: #e6ffed;
            color: var(--success-color);
            border: 1px solid #b7eb8f;
        }
        
        .error-message {
            background-color: #ffebee;
            color: var(--error-color);
            border: 1px solid #ffcdd2;
        }
        
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            transition: all 0.2s ease;
        }
        
        .back-link a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .back-link a i {
            margin-right: 5px;
        }
        
        @media (max-width: 480px) {
            .feedback-form {
                padding: 20px;
            }
            
            .rating-star {
                width: 32px;
                height: 32px;
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="feedback-container">
        <div class="feedback-header">
            <h2>Share Your Feedback</h2>
            <p>Your opinion helps us improve our services</p>
        </div>
        
        <div class="feedback-form">
            <form method="post">
                <div class="form-group">
                    <label for="category">Support Category</label>
                    <select id="category" name="category" required>
                        <option value="">Select a category</option>
                        <option value="Mental Health">Mental Health Support</option>
                        <option value="Academic Guidance">Academic Guidance</option>
                        <option value="Financial Aid">Financial Aid Assistance</option>
                        <option value="Career Counseling">Career Counseling</option>
                        <option value="Health Services">Health Services</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="comments">Your Feedback</label>
                    <textarea id="comments" name="comments" placeholder="Please share your experience with this service..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Rating</label>
                    <div class="rating-container">
                        <label class="rating-option">
                            <input type="radio" name="rating" value="1" class="rating-radio" required>
                            <div class="rating-star"><i class="fas fa-star"></i></div>
                            <span class="rating-label">Poor</span>
                        </label>
                        <label class="rating-option">
                            <input type="radio" name="rating" value="2" class="rating-radio">
                            <div class="rating-star"><i class="fas fa-star"></i></div>
                            <span class="rating-label">Fair</span>
                        </label>
                        <label class="rating-option">
                            <input type="radio" name="rating" value="3" class="rating-radio">
                            <div class="rating-star"><i class="fas fa-star"></i></div>
                            <span class="rating-label">Good</span>
                        </label>
                        <label class="rating-option">
                            <input type="radio" name="rating" value="4" class="rating-radio">
                            <div class="rating-star"><i class="fas fa-star"></i></div>
                            <span class="rating-label">Very Good</span>
                        </label>
                        <label class="rating-option">
                            <input type="radio" name="rating" value="5" class="rating-radio">
                            <div class="rating-star"><i class="fas fa-star"></i></div>
                            <span class="rating-label">Excellent</span>
                        </label>
                    </div>
                </div>
                
                <button type="submit" class="btn-submit">
                    <i class="fas fa-paper-plane"></i> Submit Feedback
                </button>
            </form>
            
            <% if (!message.isEmpty()) { %>
                <div class="message <%= message.contains("Thank") ? "success-message" : "error-message" %>">
                    <i class="fas <%= message.contains("Thank") ? "fa-check-circle" : "fa-exclamation-circle" %>"></i>
                    <%= message %>
                </div>
            <% } %>
            
            <div class="back-link">
                <a href="dashboard.jsp"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            </div>
        </div>
    </div>

    <script>
        // Enhance the rating selection
        document.addEventListener('DOMContentLoaded', function() {
            const ratingStars = document.querySelectorAll('.rating-star');
            
            ratingStars.forEach(star => {
                star.addEventListener('click', function() {
                    const radio = this.previousElementSibling;
                    radio.checked = true;
                    
                    // Update all stars up to this one
                    let currentStar = this;
                    while (currentStar) {
                        currentStar.style.backgroundColor = '#ffc107';
                        currentStar.style.color = '#ff9800';
                        currentStar = currentStar.parentElement.previousElementSibling?.querySelector('.rating-star');
                    }
                    
                    // Update all stars after this one
                    let nextStar = this.parentElement.nextElementSibling?.querySelector('.rating-star');
                    while (nextStar) {
                        nextStar.style.backgroundColor = '#f0f0f0';
                        nextStar.style.color = '#ccc';
                        nextStar = nextStar.parentElement.nextElementSibling?.querySelector('.rating-star');
                    }
                });
            });
        });
    </script>
</body>
</html>