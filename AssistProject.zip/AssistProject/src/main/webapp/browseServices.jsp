<%@ page import="java.sql.*" %>
<%@ page session="true" %>
<%
    // Redirect if not logged in
    if (session == null || session.getAttribute("username") == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    String[][] services = {
        {"Mental Health", "Support for stress, anxiety, and personal issues.", "fas fa-heart"},
        {"Academic Guidance", "Help with study skills, assignments, and time management.", "fas fa-graduation-cap"},
        {"Financial Aid", "Advice and help on financial matters, scholarships, etc.", "fas fa-hand-holding-usd"},
        {"Career Counseling", "Guidance on career paths, resumes, and interviews.", "fas fa-briefcase"},
        {"Health Services", "Medical consultations and health-related support.", "fas fa-medkit"},
        {"Disability Support", "Services and accommodations for students with disabilities.", "fas fa-wheelchair"},
        {"International Student Support", "Specialized help for international students.", "fas fa-globe-americas"},
        {"Housing Assistance", "Help with on-campus and off-campus housing.", "fas fa-home"}
    };
%>
<!DOCTYPE html>
<html>
<head>
    <title>Browse Services - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        
        .services-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .services-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .services-header h1 {
            color: var(--dark-color);
            font-size: 32px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .services-header p {
            color: #666;
            font-size: 16px;
            max-width: 700px;
            margin: 0 auto;
        }
        
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
        }
        
        .service-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
        }
        
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
        }
        
        .service-icon {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            background: var(--primary-color);
            color: white;
            padding: 25px;
            text-align: center;
            font-size: 36px;
        }
        
        .service-content {
            padding: 25px;
            flex: 1;
        }
        
        .service-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 15px;
        }
        
        .service-description {
            color: #666;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        
        .service-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .btn-learn-more {
            padding: 8px 16px;
            background: var(--primary-color);
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.2s ease;
        }
        
        .btn-learn-more:hover {
            background: var(--secondary-color);
        }
        
        .btn-book {
            padding: 8px 16px;
            background: white;
            color: var(--primary-color);
            border: 1px solid var(--primary-color);
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.2s ease;
        }
        
        .btn-book:hover {
            background: var(--primary-color);
            color: white;
        }
        
        .back-link {
            text-align: center;
            margin-top: 40px;
        }
        
        .back-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            transition: all 0.2s ease;
        }
        
        .back-link a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .back-link a i {
            margin-right: 8px;
        }
        
        @media (max-width: 768px) {
            .services-grid {
                grid-template-columns: 1fr;
            }
            
            .services-header h1 {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <div class="services-container">
        <div class="services-header">
            <h1>Our Support Services</h1>
            <p>Explore the comprehensive range of services we offer to support your academic and personal success</p>
        </div>
        
        <div class="services-grid">
            <% for(String[] service : services) { %>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="<%= service[2] %>"></i>
                    </div>
                    <div class="service-content">
                        <h3 class="service-title"><%= service[0] %></h3>
                        <p class="service-description"><%= service[1] %></p>
                        <div class="service-actions">
                            <a href="#" class="btn-learn-more">Learn More</a>
                            <a href="bookSession.jsp?category=<%= service[0] %>" class="btn-book">Book Now</a>
                        </div>
                    </div>
                </div>
            <% } %>
        </div>
        
        <div class="back-link">
            <a href="dashboard.jsp"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </div>
</body>
</html>