<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<%@ page session="true" %>
<%
    // Authentication check
    String role = (String) session.getAttribute("role");
    if (!"admin".equals(role)) {
        response.sendRedirect("login.jsp");
        return;
    }

    String searchCategory = request.getParameter("searchCategory");
    String searchStudent = request.getParameter("searchStudent");
    String message = "";

    // Handle status update
    if ("POST".equalsIgnoreCase(request.getMethod()) && request.getParameter("appointmentId") != null) {
        String appointmentId = request.getParameter("appointmentId");
        String newStatus = request.getParameter("newStatus");
        
        try {
            Class.forName("org.sqlite.JDBC");
            String dbPath = application.getRealPath("/WEB-INF/database/assist_user_data.db");
            Connection updateConn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
            
            PreparedStatement updateStmt = updateConn.prepareStatement(
                "UPDATE appointments SET status = ? WHERE id = ?");
            updateStmt.setString(1, newStatus);
            updateStmt.setInt(2, Integer.parseInt(appointmentId));
            
            int updated = updateStmt.executeUpdate();
            message = (updated > 0) ? 
                "<i class='fas fa-check-circle'></i> Appointment status updated successfully!" : 
                "<i class='fas fa-exclamation-circle'></i> Failed to update status.";
            
            updateStmt.close();
            updateConn.close();
        } catch (Exception e) {
            message = "<i class='fas fa-times-circle'></i> Error updating status: " + e.getMessage();
        }
    }

    // Database connection
    Class.forName("org.sqlite.JDBC");
    String dbPath = application.getRealPath("/WEB-INF/database/assist_user_data.db");
    Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);

    // Build query based on search
    String query = "SELECT * FROM appointments";
    boolean hasWhere = false;
    
    if (searchCategory != null && !searchCategory.trim().isEmpty()) {
        query += " WHERE category LIKE ?";
        hasWhere = true;
    }
    
    if (searchStudent != null && !searchStudent.trim().isEmpty()) {
        query += hasWhere ? " AND" : " WHERE";
        query += " student LIKE ?";
    }
    
    query += " ORDER BY created_at DESC";
    
    PreparedStatement stmt = conn.prepareStatement(query);
    int paramIndex = 1;
    
    if (searchCategory != null && !searchCategory.trim().isEmpty()) {
        stmt.setString(paramIndex++, "%" + searchCategory + "%");
    }
    
    if (searchStudent != null && !searchStudent.trim().isEmpty()) {
        stmt.setString(paramIndex++, "%" + searchStudent + "%");
    }
    
    ResultSet rs = stmt.executeQuery();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Appointments - CampusAssist</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --error-color: #ff3333;
            --warning-color: #f0ad4e;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: var(--dark-color);
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .search-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        
        .search-card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: var(--primary-color);
            display: flex;
            align-items: center;
        }
        
        .search-card h2 i {
            margin-right: 10px;
        }
        
        .search-form {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 14px;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .search-actions {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }
        
        .btn i {
            margin-right: 8px;
        }
        
        .message {
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            font-size: 14px;
            display: flex;
            align-items: center;
            animation: slideDown 0.4s ease-out;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .message-success {
            background-color: #e6ffed;
            color: var(--success-color);
            border: 1px solid #b7eb8f;
        }
        
        .message-error {
            background-color: #ffebee;
            color: var(--error-color);
            border: 1px solid #ffcdd2;
        }
        
        .appointments-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .appointments-table th {
            background: var(--primary-color);
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 500;
        }
        
        .appointments-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }
        
        .appointments-table tr:last-child td {
            border-bottom: none;
        }
        
        .appointments-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .appointments-table tr:hover {
            background-color: #f1f1f1;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-approved {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-cancelled {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .status-completed {
            background-color: #e2e3e5;
            color: #383d41;
        }
        
        .action-form {
            display: flex;
            gap: 10px;
        }
        
        .action-form select {
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 13px;
        }
        
        .action-form button {
            padding: 5px 10px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.2s ease;
        }
        
        .action-form button:hover {
            background: var(--secondary-color);
        }
        
        .no-results {
            text-align: center;
            padding: 30px;
            color: #666;
            font-style: italic;
        }
        
        .back-link {
            margin-top: 30px;
        }
        
        .back-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            transition: all 0.2s ease;
        }
        
        .back-link a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .back-link a i {
            margin-right: 8px;
        }
        
        .search-results-info {
            margin-bottom: 15px;
            color: #666;
            font-size: 14px;
        }
        
        @media (max-width: 768px) {
            .search-form {
                grid-template-columns: 1fr;
            }
            
            .appointments-table {
                display: block;
                overflow-x: auto;
            }
            
            .action-form {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Appointment Management</h1>
            <a href="adminDashboard.jsp" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <% if (!message.isEmpty()) { %>
            <div class="message <%= message.contains("successfully") ? "message-success" : "message-error" %>">
                <%= message %>
            </div>
        <% } %>
        
        <!-- Search Card -->
        <div class="search-card">
            <h2><i class="fas fa-search"></i> Search Appointments</h2>
            
            <form method="get" class="search-form">
                <div class="form-group">
                    <label for="searchCategory">Category</label>
                    <input type="text" id="searchCategory" name="searchCategory" 
                           placeholder="e.g., Mental Health" value="<%= searchCategory != null ? searchCategory : "" %>">
                </div>
                
                <div class="form-group">
                    <label for="searchStudent">Student Name</label>
                    <input type="text" id="searchStudent" name="searchStudent" 
                           placeholder="e.g., John Doe" value="<%= searchStudent != null ? searchStudent : "" %>">
                </div>
                
                <div class="search-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Search
                    </button>
                    <a href="manageAppointments.jsp" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Clear
                    </a>
                </div>
            </form>
            
            <% if ((searchCategory != null && !searchCategory.trim().isEmpty()) || 
                  (searchStudent != null && !searchStudent.trim().isEmpty())) { %>
                <div class="search-results-info">
                    Showing results for: 
                    <% if (searchCategory != null && !searchCategory.trim().isEmpty()) { %>
                        <strong>Category: <%= searchCategory %></strong>
                    <% } %>
                    <% if (searchStudent != null && !searchStudent.trim().isEmpty()) { %>
                        <% if (searchCategory != null && !searchCategory.trim().isEmpty()) { %> | <% } %>
                        <strong>Student: <%= searchStudent %></strong>
                    <% } %>
                </div>
            <% } %>
        </div>
        
        <!-- Appointments Table -->
        <table class="appointments-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Student</th>
                    <th>Category</th>
                    <th>Time Slot</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <% 
                boolean hasData = false;
                while (rs.next()) { 
                    hasData = true;
                    String currentStatus = rs.getString("status");
                    String statusClass = "status-pending";
                    if ("Approved".equalsIgnoreCase(currentStatus)) statusClass = "status-approved";
                    else if ("Cancelled".equalsIgnoreCase(currentStatus)) statusClass = "status-cancelled";
                    else if ("Completed".equalsIgnoreCase(currentStatus)) statusClass = "status-completed";
                %>
                    <tr>
                        <td><%= rs.getInt("id") %></td>
                        <td><%= rs.getString("student") %></td>
                        <td><%= rs.getString("category") %></td>
                        <td><%= rs.getString("timeSlot") %></td>
                        <td>
                            <span class="status-badge <%= statusClass %>">
                                <%= currentStatus %>
                            </span>
                        </td>
                        <td><%= rs.getString("created_at") %></td>
                        <td>
                            <form method="post" class="action-form">
                                <input type="hidden" name="appointmentId" value="<%= rs.getInt("id") %>">
                                <select name="newStatus">
                                    <option value="Pending" <%= "Pending".equals(currentStatus) ? "selected" : "" %>>Pending</option>
                                    <option value="Approved" <%= "Approved".equals(currentStatus) ? "selected" : "" %>>Approved</option>
                                    <option value="Cancelled" <%= "Cancelled".equals(currentStatus) ? "selected" : "" %>>Cancelled</option>
                                    <option value="Completed" <%= "Completed".equals(currentStatus) ? "selected" : "" %>>Completed</option>
                                </select>
                                <button type="submit">
                                    <i class="fas fa-save"></i> Update
                                </button>
                            </form>
                        </td>
                    </tr>
                <% } %>
                
                <% if (!hasData) { %>
                    <tr>
                        <td colspan="7" class="no-results">
                            <i class="fas fa-info-circle"></i> No appointments found
                            <% if (searchCategory != null || searchStudent != null) { %>
                                matching your search criteria.
                            <% } else { %>
                                in the system.
                            <% } %>
                        </td>
                    </tr>
                <% } %>
            </tbody>
        </table>
        
        <div class="back-link">
            <a href="adminDashboard.jsp"><i class="fas fa-arrow-left"></i> Back to Admin Dashboard</a>
        </div>
    </div>
</body>
</html>
<%
    // Close database resources
    if (rs != null) rs.close();
    if (stmt != null) stmt.close();
    if (conn != null) conn.close();
%>