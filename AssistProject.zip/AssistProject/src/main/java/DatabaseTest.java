import org.junit.*;
import java.sql.*;

public class DatabaseTest {
    private static Connection conn;
    
    @BeforeClass
    public static void setUp() throws Exception {
        // Initialize test database
        Class.forName("org.sqlite.JDBC");
        conn = DriverManager.getConnection("jdbc:sqlite:test.db");
        
        // Create test tables
        Statement stmt = conn.createStatement();
        stmt.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT, user_type TEXT)");
        // Add other tables...
    }
    
    @Test
    public void testUserLogin() throws SQLException {
        // Insert test user
        PreparedStatement pstmt = conn.prepareStatement("INSERT INTO users (username, password, user_type) VALUES (?, ?, ?)");
        pstmt.setString(1, "testuser");
        pstmt.setString(2, "testpass");
        pstmt.setString(3, "student");
        pstmt.executeUpdate();
        
        // Test login
        pstmt = conn.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?");
        pstmt.setString(1, "testuser");
        pstmt.setString(2, "testpass");
        ResultSet rs = pstmt.executeQuery();
        
        Assert.assertTrue("User should exist", rs.next());
        Assert.assertEquals("User type should be student", "student", rs.getString("user_type"));
    }
    
    @AfterClass
    public static void tearDown() throws Exception {
        if (conn != null) {
            conn.close();
        }
    }
}